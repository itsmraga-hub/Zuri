def add(x, y):
    return x + y


sum = add(4, 5)
print(sum)
